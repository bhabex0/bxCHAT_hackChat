/**
  * HackChat main server entry point
  * @author Marzavec ( https://github.com/marzavec )
  * @version v2.0.0
  * @license WTFPL ( http://www.wtfpl.net/txt/copying/ )
  */

export { default as CoreApp } from './src/serverLib/CoreApp.js';


