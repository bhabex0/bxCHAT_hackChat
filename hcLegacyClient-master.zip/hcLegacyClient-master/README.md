# hcLegacyClient
The original legacy hack.chat client
