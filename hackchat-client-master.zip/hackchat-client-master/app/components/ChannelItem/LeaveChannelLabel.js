/**
 * Exports a styled wrapper for the 'leave channel' button
 */

import styled from 'styled-components';

export default styled.span`
  color: #f04747 !important;
`;
