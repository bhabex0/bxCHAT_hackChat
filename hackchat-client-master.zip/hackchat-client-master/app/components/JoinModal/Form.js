/**
 * Exports a styled form element
 */

import styled from 'styled-components';

const Form = styled.form`
  background-color: rgba(0, 0, 0, 0);
`;

export default Form;
