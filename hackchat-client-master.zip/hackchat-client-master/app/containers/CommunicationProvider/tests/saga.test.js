/* eslint-disable redux-saga/yield-effects */

/**
 * Communication provider tests
 */

// import { take, call, put, takeLatest } from 'redux-saga/effects';
// import communicationProviderSaga from '../saga';

// const generator = communicationProviderSaga();

describe('communicationProviderSaga Saga', () => {
  it.skip('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
