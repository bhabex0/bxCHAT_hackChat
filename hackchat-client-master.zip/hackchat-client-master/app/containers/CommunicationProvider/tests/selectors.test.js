/**
 * Communication provider tests
 */

// import { selectCommunicationProviderDomain } from '../selectors';

describe('selectCommunicationProviderDomain', () => {
  it.skip('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
