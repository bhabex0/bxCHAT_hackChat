/**
 * Enables code splitting for the SettingsPage
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
