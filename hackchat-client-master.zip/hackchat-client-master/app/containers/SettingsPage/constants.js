/**
 * SettingsPage action & reducer constants
 */

export const DEFAULT_ACTION = 'app/SettingsPage/DEFAULT_ACTION';
