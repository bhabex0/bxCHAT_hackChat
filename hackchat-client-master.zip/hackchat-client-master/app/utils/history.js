/**
 * Exports a new history session management instance
 */

import { createBrowserHistory } from 'history';
const history = createBrowserHistory();
export default history;
