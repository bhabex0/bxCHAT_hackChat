/**
 * Required by the jest unit testing module
 */
import '@babel/polyfill';
