/**
 * Required by the jest unit testing module
 */

module.exports = 'CSS_MODULE';
