/**
 * Required by the jest unit testing module
 */

module.exports = 'IMAGE_MOCK';
