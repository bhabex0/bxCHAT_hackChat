# Install Scripts

The scripts contained in this repo can be used to easily install hack.chat on a linux or windows system. The lines below will assist in downloading and running the install scripts.

---

## Ubuntu or Debian

```
curl -fsSL https://raw.githubusercontent.com/hack-chat/install-scripts/main/hcInstall.sh | bash -
```

or

```
wget -qO- https://raw.githubusercontent.com/hack-chat/install-scripts/main/hcInstall.sh | bash -
```

then

```
npm run start
```

## Windows

```
Coming soon ;]
```
